/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_358(unsigned x)
{
    return x + 3284633932U;
}

void setval_327(unsigned *p)
{
    *p = 2425393240U;
}

unsigned addval_170(unsigned x)
{
    return x + 3347597535U;
}

unsigned getval_291()
{
    return 3347662878U;
}

unsigned getval_173()
{
    return 3284633928U;
}

unsigned getval_342()
{
    return 2423847742U;
}

unsigned getval_221()
{
    return 2425379040U;
}

unsigned addval_132(unsigned x)
{
    return x + 1347418999U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_212()
{
    return 3375939977U;
}

unsigned addval_475(unsigned x)
{
    return x + 3372794241U;
}

void setval_162(unsigned *p)
{
    *p = 3531921033U;
}

unsigned addval_338(unsigned x)
{
    return x + 3380926121U;
}

unsigned getval_285()
{
    return 3374369417U;
}

void setval_180(unsigned *p)
{
    *p = 3248078105U;
}

unsigned getval_387()
{
    return 3286272840U;
}

unsigned addval_485(unsigned x)
{
    return x + 3223374345U;
}

unsigned addval_479(unsigned x)
{
    return x + 3229925768U;
}

unsigned getval_323()
{
    return 3251276229U;
}

unsigned addval_330(unsigned x)
{
    return x + 3222850185U;
}

unsigned addval_394(unsigned x)
{
    return x + 3523789209U;
}

unsigned getval_458()
{
    return 3269495112U;
}

unsigned getval_126()
{
    return 3767093458U;
}

unsigned getval_354()
{
    return 3525367449U;
}

void setval_464(unsigned *p)
{
    *p = 2429192661U;
}

void setval_316(unsigned *p)
{
    *p = 3372796552U;
}

unsigned addval_296(unsigned x)
{
    return x + 3264272009U;
}

void setval_286(unsigned *p)
{
    *p = 3676886665U;
}

unsigned addval_383(unsigned x)
{
    return x + 3286270280U;
}

unsigned getval_218()
{
    return 2445380036U;
}

unsigned getval_154()
{
    return 2425408129U;
}

unsigned addval_103(unsigned x)
{
    return x + 3380920717U;
}

unsigned addval_482(unsigned x)
{
    return x + 2425405833U;
}

unsigned addval_133(unsigned x)
{
    return x + 2497743176U;
}

unsigned addval_308(unsigned x)
{
    return x + 3286272456U;
}

unsigned addval_340(unsigned x)
{
    return x + 3286272328U;
}

void setval_347(unsigned *p)
{
    *p = 3531921033U;
}

unsigned addval_474(unsigned x)
{
    return x + 3269495112U;
}

unsigned addval_213(unsigned x)
{
    return x + 3224426121U;
}

unsigned addval_109(unsigned x)
{
    return x + 3374893705U;
}

unsigned addval_305(unsigned x)
{
    return x + 3374372493U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
